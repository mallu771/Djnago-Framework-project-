from django.contrib import admin

from .models import Admin
# Register your models here.

admin.site.register(Admin)

